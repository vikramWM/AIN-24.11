@extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
       
	</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<!-- <li><a href="/">Home</a></li>
					<li>Chemistry Assignment</li> -->
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Benefits of Assignment in Need Assignments Writing Help Services for Students All Over the World
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Ratting</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column mr-0 pb-0 pl-0" style="background-color: white; border-radius: 10px;box-shadow: 10px;box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08)">
					@if ($errors->any())
						<div id="errorAlert" class="alert alert-danger mt-5">
							<ul>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
						<script>
							setTimeout(function() {
								document.getElementById('errorAlert').style.display = 'none';
							}, 10000); // Hide the error message after 10 seconds (10000 milliseconds)
						</script>
					@endif
					<div class="offer-badge"><img src="assets/media/avatars/offer.png" alt=""></div> 
					<form id="orderForm" action="/neworder-fromhome" method="POST" enctype="multipart/form-data">
							<div class="form-header text-center p-2">
								<h2 class="order-now">Get Assignment Instantly</h2>
							</div>
						@csrf
						<div class="contact-form p-4">
							@if(Auth::user() == '')
							<div class="row">
								<div class="col-md-6">
									<div class="form-group" >
									<label for="">Name</label>
										<input type="text" name="user_name" class="form-control input-color" placeholder="Your Full Name*" required="" style="background-color:#f1f1f1; height: 45px;">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="">Email</label>
										<input type="email" name="email" class="form-control" placeholder="Your Email Address*" required="" style="background-color:#f1f1f1; height: 45px;">
									</div>
								</div>
							</div>
							<input type="hidden" name="countrycode" id="country_c">
							<div class="row">
								<div class="col-md-6" style="width:100%">
									<div class="form-group">
										<label for="">Number</label>
										<input type="tel" name="mobile" class="form-control"  placeholder="Phone*" id="phone_number"  style="background-color:#f1f1f1;height: 45px;"/>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="">deadline</label>
										<input type="date" name="delivery_date" id="DeliveryDate" class="form-control" required="" placeholder="deadline" style="background-color:#f1f1f1;height: 45px;">
									</div>
								</div>
							</div>
							@else
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="">deadline</label>
										<input type="date" name="delivery_date" id="DeliveryDate" class="form-control" required="" placeholder="deadline" style="background-color:#f1f1f1;height: 45px;">
									</div>
								</div>
							</div>


							@endif
							
							<div class="row">

							</div>
							
							<div class="policy_agree">
								<input type="checkbox" required="">&nbsp;I agree with Privacy Policy and Terms &amp; Conditions (Recommended) 
							</div>
							<div class="g-recaptcha" data-sitekey="{{ config('services.recaptcha.site_key') }}"></div>
							<div class="col-md-12 text-center" >
								<button class=" place-order" type="submit">Place Order</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			</section>
	
	

	<!-- Our Writer -->
	<section class="testimonial-section-three">
		<div class="color-layer" style="width:100%"></div>
		<div class="icon-layer-four" style="background-image:url(images2/icons/pattern-4.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title text-center py-2" >
				<h2>Assignment In Need Expert Writers</h2>
			</div>
			<div class="testimonial-carousel-three owl-carousel owl-theme py-0">
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>6
						<h6>Michal dravid</h6>
						<div class="designation">English Literature: (Writer)</div>
						<div class="text " style="text-align: justify;">With a master's degree in English Literature from the University of London, I have assisted numerous college scholars in crafting compelling assignments, dissertations, and theses. My deep knowledge of literary analysis and critical theory  
                         <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div style="display:none">has been invaluable to students across various academic levels.</div>    
					</div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Mahfuz Riad</h6>
						<div class="designation">History (Writer)</div>
						<div class="text" style="text-align: justify;">I have effectively supported a wide range of students in mastering their History assignments. My proficiency includes Political History, Diplomatic History, Cultural History, and Social History, ensuring comprehensive and insightful work for 
                         <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div style="display:none">students tackling these complex subjects.</div>
					</div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Muhibbur Rashid</h6>
						<div class="designation">Law (Writer)</div>
						<div class="text" style="text-align: justify;">Having extensive experience in Legal Studies, I have aided numerous students in navigating their Law assignments with ease. My specialization includes Taxation Law, Labor Law, Criminal Law, and Civil Law, helping students produce 
                            <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div  style="display:none">well-researched and well-argued legal papers</div>
                    </div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Tamim Anj</h6>
						<div class="designation">Finance (writer)</div>
						<div class="text" style="text-align: justify;">I have guided many students in excelling at their Finance assignments, offering expertise in Corporate Finance, Investment Analysis, Financial Management, and Risk Assessment. My assistance ensures students can submit accurate 
                        <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div  style="display:none">and insightful financial reports and analyses.</div>
					</div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Ajay ravi</h6>
						<div class="designation">Engineering (Writer)</div>
						<div class="text" style="text-align: justify;">With a strong background in various engineering disciplines, I have helped numerous students tackle their Engineering assignments. From Electrical Engineering to Mechanical Engineering and Civil Engineering, my support covers 
                        <span style="color:blue"> <i>Continue...</i></span>

                        </div>
                        <div style="display:none">essential topics and complex problems to ensure academic success</div>
                    
                    </div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Daniel watson</h6>
						<div class="designation">Chemistry (writer)</div>
						<div class="text" style="text-align: justify;">I have effectively supported students in overcoming their Chemistry assignment challenges. My expertise includes Organic Chemistry, Inorganic Chemistry, Physical Chemistry, and Analytical Chemistry, providing detailed and
                        <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                       
                        <div style="display:none"> precise assistance for all chemistry-related tasks.</div>

                    </div>
				</div>
				
			</div>
		</div>
	</section>

    <!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

    <!--Chemistry Assignment Help | Get Professional Assistance Today! -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Advantage Of Assignment in Need For Online Assignments Help</h2>
                              <p>At <a href="https://www.assignnmentinneed.com/"><b>Assignment In Need</b></a>, we provide top-notch help for assignments to students all over the world, focusing especially on the UK, Canada, Australia, UAE, Malaysia, Spain and more. Our More than 45,000 assignments have already been completed. Students speak highly of us, with around 30,000 satisfied students. Our student retention rate is an impressive 98%, showing that many return for help. A big team of over 3,000 PhD experts keeps working hard every day. This effort leads to excellent assignment support, <a href="https://www.assignnmentinneed.com/why-choose-us"><b>making Assignment in Need choose for online assignment help</b></a>. Many students see grades around 9 out of 10, which is good.</p>
							
							 
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our assignment service today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>
	<!-- Get Chemistry Assignment Help from Experts -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Expert Knowledge and Specialised Assistance for Every Assignment and Every Stage of Education</h2>
                           <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Access to Highly Qualified Writers</b></h3></div>
                                    <p>We connect students with highly qualified writers who hold advanced degrees in their respective fields. These professionals possess the expertise and experience to deliver exceptional assignments that meet rigorous academic standards.</p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>In-Depth Research and Insight</b></h3></div>
                                        <p>Each assignment we deliver is backed by comprehensive research and insightful analysis. Our writers delve deep into your topic, sourcing information from credible academic journals, books, and other resources to provide well-rounded and authoritative content</p>  
                                    </li>
                            </ul>
                           </div>
                
               
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
    <!--Topics We Cover Under Our Chemistry Assignment Help Online -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Enhancing Your Academic Understanding and Skills
                            </h2>

                            <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>How Quality Content Leads to Better Grades
                                        </b></h3></div>
                                    <p>High-quality assignments are key to achieving better grades, and our team ensures every piece of work meets the highest standards. With a focus on clarity, coherence, and originality, our content helps you stand out academically.
                                    </p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>Supporting Your Learning Journey</b></h3></div>
                                      <p>At Assignment In Need, we are committed to supporting your overall learning journey. Our assignments are crafted to provide insights and examples that deepen your understanding of the subject. By delivering expertly written content, we help you navigate the challenges of your academic path confidently, making us one of the best assignment writing services available. </p>   
                                    </li>
                            </ul>
                           </div>
                
  
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

    <!-- Overcoming Common Chemistry Challenges -->
    <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Stress-Free Assignment Submission</h2>

                            <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Reducing Stress with Timely Support</b></h3></div>
                                    <p>We understand the pressures of academic life, which is why we prioritize timely support for every assignment. By ensuring prompt delivery, we help you avoid last-minute anxiety and create a stress-free academic experience.</p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>No More Last-Minute Panic</b></h3></div>
                                      <p>Say goodbye to last-minute panic with Assignment In Need. We are here to take the pressure off by handling your assignments with efficiency and expertise. Our team works diligently to ensure that even urgent tasks are completed without compromising quality. </p>   
                                    </li>
                            </ul>
                           </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
       
    <!-- Why Do Students Need Help with Chemistry Assignments? -->
    <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Learning and Skill Enhancement with Assignment Help</h2>

							<div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Gaining Insight into Complex Topics</b></h3></div>
                                    <p>Understanding complex topics becomes simpler with our assistance. Our writers break down intricate concepts into comprehensible and engaging content, making it easier for you to learn.</p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>Improving Academic Writing Skills</b></h3></div>
                                      <p>Our expertly written assignments are perfect examples of top-tier academic writing. By reviewing our work, you can learn how to structure arguments, cite sources, and maintain academic tone and style. </p>   
                                    </li>
                            </ul>
                           </div> 
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

     <!--Having a tough time with your chemistry assignment? Try our assignment help -->
     <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Saving Time for Other Academic Tasks and Personal Growth</h2>

                            <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Saving Time for Other Priorities</b></h3></div>
                                    <p>Balancing academic and personal responsibilities is easier with Assignment In Need. By delegating your assignments to us, you can free up valuable time for other priorities, such as preparing for exams or pursuing hobbies.</p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>Focus on Your Other Academic Tasks and Personal Growth</b></h3></div>
                                      <p>With our help, you can devote more attention to other academic tasks and personal development. By handling your assignments, we enable you to focus on projects, presentations, and self-improvement initiatives that contribute to your overall growth. </p>   
                                    </li>
                            </ul>
                           </div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- new section -->

    <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Cost-Effective and Affordable Help</h2>

                            <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Competitive Pricing without Sacrificing Quality</b></h3></div>
                                    <p>We believe that affordability should never come at the cost of quality. Our assignment writing website pricing structure is transparent and competitive, ensuring that you get the best value for your investment.</p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>Flexible Payment Options</b></h3></div>
                                      <p>To make our assignment writing services even more accessible, we offer flexible payment options tailored to your needs. Whether you prefer instalment plans or one-time payments, we provide solutions that work for you. </p>   
                                    </li>
                            </ul>
                           </div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


    <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Improved Confidence in Assignments Submissions</h2>

                            <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Submitting Work You Can Be Proud Of</b></h3></div>
                                    <p>Every assignment we deliver is a reflection of your academic abilities and effort. Our team ensures that your work is polished, original, and impactful, so you can submit assignments that you’re genuinely proud of.</p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>Achieving Academic Success with Assignments Submissions</b></h3></div>
                                      <p>Success in academics starts with submitting quality assignments, and we help you achieve that goal. By providing exceptional support and resources, we enable you to excel in your coursework and achieve outstanding results. </p>   
                                    </li>
                            </ul>
                           </div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


    <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Improving Your Academic Writing through Constructive Feedback </h2>

                            <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Review to Improve Your Writing Skills</b></h3></div>
                                    <p>Our expert reviews focus on improving your academic writing skills by identifying gaps and suggesting enhancements. By learning from our feedback, you can develop stronger arguments, clearer structures, and more effective communication.</p>
                                    </li>
                                   
                            </ul>
                           </div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>



    <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Confidence in Meeting Deadlines and Academic Requirements</h2>

                            <div>
                           <ul> 
                                    <li>
                                        <div class="mb-2"><h3><b>Support for Every Deadline
                                        </b></h3></div>
                                    <p>No matter how tight your deadline is, we are here to help. Our team works efficiently to deliver assignments within your required timeframe without compromising quality. Trust us to handle your urgent tasks while you focus on other important academic responsibilities.</p>
                                    </li>
                                    <li>
                                        <div class="mb-2"><h3><b>Adhering to Specific University and Course Guidelines
                                        </b></h3></div>
                                      <p>We understand the importance of adhering to your university and course guidelines. Our writers meticulously follow instructions to ensure that every assignment meets your institution’s specific requirements.
                                      </p>   
                                    </li>
                            </ul>
                           </div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

    <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Step-by-Step Solution on Every Assignment</h2>

                            <div>
                         <p>A detailed, step-by-step approach is what we offer for each assignment. Writers on our team break down complex tasks into easy steps. This method makes sure that every requirement gets met accurately. Starting from initial research and going to the final draft, our careful process takes care of everything, making us a trusted choice for assignment writing help. </p>
                           </div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

    <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Custom Solutions for Every Subject</h2>

                            <div>
                         <p>At Assignment In Need, we know that each subject comes with different challenges. Engineering, literature, or business studies all require special attention. Custom solutions are what we offer to fit the needs of your specific subject. </p>
                           </div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

            <!-- end new section -->

       	  
 <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
 <section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Assignment Writing Help</b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. How does assignment help reduce academic stress?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <P>Getting assignment help can cut down stress. Timely assistance arrives just when you need it. This way, you submit high-quality work without rushing at the last minute. </P>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2.Can assignments help improve my writing and research skills?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <P>Yes, getting assignments that are well-written helps you understand how to structure your own work. </P>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. How does assignment help save time for other academic responsibilities?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <P>Outsourcing assignments gives you more time. This extra time can help you study for exams or get involved in extracurricular activities. </P>
										</div>
                                    </div>
                                </div>
                            </li>
                            </div>
                    <div class="column col-lg-6 col-md-6 col-sm-12">    
                       <ul class="accordion-box"> 
							<li class="accordion block"> 
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4.What makes your service more reliable than others?
                                <div class="icon fa fa-angle-down"></div></div>
                                  <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <P>Our service is different because we have more than 3,000 PhD experts on our team. A 98% client return rate shows that people like what we do.</P>
										</div>
                                    </div>
                                  </div>
                            </li>
						 
                  	
					
			
			
				     <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">5. Can I trust that my assignments will be plagiarism-free?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <P>Absolutely, we guarantee that all work is 100% plagiarism-free. Each assignment goes through a thorough check for originality.</P>
										</div>
                                    </div>
                                </div>
                            </li>
							
						
					 
						 
					
                        </ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <button style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</button>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 
 
@endsection