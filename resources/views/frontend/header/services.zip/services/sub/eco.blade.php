@extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>
	 <!-- new code of conclusion -->
       <style>
		.conclsn{
			padding: 70px 0px ;
            
		}
	   </style>
	  <!-- end new code of conclusion -->
	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      /* Assignment Writing */
	</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<li><a href="/">Home</a></li>
					<li>Economic</li>
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center"> Economic Assignment Help from Experts | Now at 40% OFF
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Ratting</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column mr-0 pb-0 pl-0" style="background-color: white; border-radius: 10px;box-shadow: 10px;box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08)">
					@if ($errors->any())
						<div id="errorAlert" class="alert alert-danger mt-5">
							<ul>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
						<script>
							setTimeout(function() {
								document.getElementById('errorAlert').style.display = 'none';
							}, 10000); // Hide the error message after 10 seconds (10000 milliseconds)
						</script>
					@endif
					<div class="offer-badge"><img src="assets/media/avatars/offer.png" alt=""></div> 
					<form id="orderForm" action="/neworder-fromhome" method="POST" enctype="multipart/form-data">
							<div class="form-header text-center p-2">
								<h2 class="order-now">Get Assignment Instantly</h2>
							</div>
						@csrf
						<div class="contact-form p-4">
							@if(Auth::user() == '')
							<div class="row">
								<div class="col-md-6">
									<div class="form-group" >
									<label for="">Name</label>
										<input type="text" name="user_name" class="form-control input-color" placeholder="Your Full Name*" required="" style="background-color:#f1f1f1; height: 45px;">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="">Email</label>
										<input type="email" name="email" class="form-control" placeholder="Your Email Address*" required="" style="background-color:#f1f1f1; height: 45px;">
									</div>
								</div>
							</div>
							<input type="hidden" name="countrycode" id="country_c">
							<div class="row">
								<div class="col-md-6" style="width:100%">
									<div class="form-group">
										<label for="">Number</label>
										<input type="tel" name="mobile" class="form-control"  placeholder="Phone*" id="phone_number"  style="background-color:#f1f1f1;height: 45px;"/>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="">deadline</label>
										<input type="date" name="delivery_date" id="DeliveryDate" class="form-control" required="" placeholder="deadline" style="background-color:#f1f1f1;height: 45px;">
									</div>
								</div>
							</div>
							@else
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="">deadline</label>
										<input type="date" name="delivery_date" id="DeliveryDate" class="form-control" required="" placeholder="deadline" style="background-color:#f1f1f1;height: 45px;">
									</div>
								</div>
							</div>


							@endif
							
							<div class="row">

							</div>
							
							<div class="policy_agree">
								<input type="checkbox" required="">&nbsp;I agree with Privacy Policy and Terms &amp; Conditions (Recommended) 
							</div>
							<div class="g-recaptcha" data-sitekey="{{ config('services.recaptcha.site_key') }}"></div>
							<div class="col-md-12 text-center" >
								<button class=" place-order" type="submit">Place Order</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			</section>
			<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">Our Procedure</h2>
					<p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p>
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Fill in the 'order now' form, mention your basic information and specific requirements that you want us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay an affordable price for the assignment help provided to you via our secure payment gateway that is fully protected from privacy infringements.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
											Get a high-quality assignment writing services by our expert writers within the given deadline and score better than your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
	<section class="testimonial-section-three">
		<div class="color-layer" style="width:100%"></div>
		<div class="icon-layer-four" style="background-image:url(images2/icons/pattern-4.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title mt-2" >
				<h2>Our Writer</h2>
			</div>
			<div class="testimonial-carousel-three owl-carousel owl-theme py-0">
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>6
						<h6>Michal dravid</h6>
						<div class="designation">English Literature: (Writer)</div>
						<div class="text " style="text-align: justify;">With a master's degree in English Literature from the University of London, I have assisted numerous college scholars in crafting compelling assignments, dissertations, and theses. My deep knowledge of literary analysis and critical theory  
                         <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div style="display:none">has been invaluable to students across various academic levels.</div>    
					</div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Mahfuz Riad</h6>
						<div class="designation">History (Writer)</div>
						<div class="text" style="text-align: justify;">I have effectively supported a wide range of students in mastering their History assignments. My proficiency includes Political History, Diplomatic History, Cultural History, and Social History, ensuring comprehensive and insightful work for 
                         <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div style="display:none">students tackling these complex subjects.</div>
					</div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Muhibbur Rashid</h6>
						<div class="designation">Law (Writer)</div>
						<div class="text" style="text-align: justify;">Having extensive experience in Legal Studies, I have aided numerous students in navigating their Law assignments with ease. My specialization includes Taxation Law, Labor Law, Criminal Law, and Civil Law, helping students produce 
                            <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div  style="display:none">well-researched and well-argued legal papers</div>
                    </div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Tamim Anj</h6>
						<div class="designation">Finance (writer)</div>
						<div class="text" style="text-align: justify;">I have guided many students in excelling at their Finance assignments, offering expertise in Corporate Finance, Investment Analysis, Financial Management, and Risk Assessment. My assistance ensures students can submit accurate 
                        <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                        <div  style="display:none">and insightful financial reports and analyses.</div>
					</div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Ajay ravi</h6>
						<div class="designation">Engineering (Writer)</div>
						<div class="text" style="text-align: justify;">With a strong background in various engineering disciplines, I have helped numerous students tackle their Engineering assignments. From Electrical Engineering to Mechanical Engineering and Civil Engineering, my support covers 
                        <span style="color:blue"> <i>Continue...</i></span>

                        </div>
                        <div style="display:none">essential topics and complex problems to ensure academic success</div>
                    
                    </div>
				</div>
				
				<!-- Testimonial Block Three -->
				<div class="testimonial-block-three">
					<div class="inner-box">
						<div class="image-outer">
							<div class="image">
								<img src="/assets/media/avatars/blank.png" alt="" />
							</div>
							<div class="quote flaticon-left-quote"></div>
						</div>
						<h6>Daniel watson</h6>
						<div class="designation">Chemistry (writer)</div>
						<div class="text" style="text-align: justify;">I have effectively supported students in overcoming their Chemistry assignment challenges. My expertise includes Organic Chemistry, Inorganic Chemistry, Physical Chemistry, and Analytical Chemistry, providing detailed and
                        <span style="color:blue"> <i>Continue...</i></span>
                        </div>
                       
                        <div style="display:none"> precise assistance for all chemistry-related tasks.</div>

                    </div>
				</div>
				
			</div>
		</div>
	</section>

    <!--Assignment Writing Help In  Economic -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Assignment Writing Help In  Economic</h2>
                           <p> Are you someone who needs economics assignment help? Is it because you struggle with your economics classes which makes it difficult for you to tackle your homework and assignments?
                           </p>
							 <p>The focus of economics on how people and business behave in an economy makes it an important part of social sciences. And it is really important for students to develop logical, theoretical, and analytical skills to understand such complex economics concepts. 
                             </p>
                             <p>But sometimes traditional classroom teaching alone isn't enough. That's where Assignment In Need comes in. Who are we? We are an educational platform that helps students excel in subjects like economics. We have a dedicated team of economics experts that prioritize your academic success with their economics assignment help online. 
                             </p>
                             <p> Whether you need assistance or are struggling with understanding tough concepts, we at Assignnment In Need are here to help you succeed  with our economic assignment help.
                             </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our assignment service today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>
	<!--Why You Need Economic Assignment Help -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why You Need Economic Assignment Help</h2>
                           
                          <p>With part-time jobs to cover living expenses, balancing work, studies, and other responsibilities can be tough and stressful for any student in today's day and age. And it is normal to look for economics assignment help when managing coursework deadlines and the fast paced life seems a little difficult.</p>
							 <p>Additionally when you take expert economics assignment help online, you also get quality assurance, personalized support , and a deeper understanding of the world of economics. This can boost your academic confidence, learning pace, and even academic success. </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
    <!--Our Economic Assignment Help Services -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Our Economic Assignment Help Services</h2>
                           
                            <p>We at Assignment In Need have made sure that you get the best possible economic assignment help online. This is the reason why we have made significant investments in recruiting top economic experts from worldwide to ensure that every assignment is crafted and customized based on your needs.</p>
                            <p>But we don't just stop at that, each and every assignment goes through multiple quality checks and reviews by our quality control team in economics. The assignment gets approved only after it meets all criteria. </p>
                            <p>Some of our economic assignment help services include:</p>


                          
                        <p><b>Custom Economic Assignment Writing: </b> Every economics assignment is specifically tailored to meet your needs by our team of expert writers. We at Assignment In Need provide well-researched and original content of highest academic quality be it an essay, research paper or just a case study.</p>

                        <p><b>Economic Assignment Editing and Proofreading: </b> We have a rigorous editing and proofreading process where we focus on structure, grammar, and formatting to improve clarity and coherence to make sure your assignments are error-free and polished.</p>

                        <p><b>24/7 Economic Assignment Support: </b> We have a dedicated support team who are available 24/7 to answer all of your questions and “someone please do my economics assignment” moments because we understand that deadlines can be stressful. We provide updates on your assignments, and offer assistance whenever you need it.</p>

                        <p><b>Get Our Service Around the World: </b> You can access our assignment writing services no matter where you are. Our primary locations are London, UK, and Canada, but we also serve students in Malaysia, Australia, Spain, and the UAE. Wherever you are, we're here to help with your assignments!</p>
 
  
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

    <!-- How Our Economic Assignment Help Stands Out -->
    <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">How Our Economic Assignment Help Stands Out</h2>
                            <p>If you ever think, 'I need someone to write my economics assignment,' then our economics assignment help online is here for you. But why choose us? Here's why:</p>
                           <p><b>Experienced Economic Assignment Help Experts: </b> Our team consists of experienced professionals who know economics inside out. They ensure your assignments not only meet academic standards but also show a strong grasp of economic concepts.</p>

                           <p><b>Affordable Economic Assignment Help Online: </b> Worried about burning  a hole in your pocket? Don't worry, we offer budget-friendly prices and exciting offers for our economic assignment help. Currently, we are offering 40% off to new users. You can check for more such offers here at <a href="/">Assignment in Need Offers. </a></p>

                           <p><b>Timely Delivery of Economic Assignments Help: </b> Don't worry about missing deadlines, we understand how important deadlines can be. This is the reason why our assignment expert economics makes sure to deliver your economic assignments on time, no matter how tight the deadline or complex the task may be.</p>
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
       
    <!-- What Makes Us A Reliable Economics Assignment Writing Service? -->
    <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">What Makes Us A Reliable Economics Assignment Writing Service?</h2>
                           
                            <p>Even with years of study economics can be quite complex. Our assignment expert economics at Assignnment In Need provides unique economic assignment help online that can help you understand core concepts. Below are some of the few reasons why you should choose us for your <b>economics homework help:</b></p>
                
                             <p><b>Originality Guarantee: </b> A cornerstone of our online economics assignment help is originality. Our experts use their deep subject knowledge and experience to ensure each assignment is unique and is written from scratch. </p>
                             <p><b>24/7 Support: </b> Our support team is available round-the-clock to assist with any queries you have. We provide constant updates on your assignment's progress and resolve issues promptly.</p>
                             <p><b>High-Quality Assignments: </b> Our writing standards are exceptional and have helped countless students. Your economic assignment undergoes rigorous checks to ensure it is clear, impactful, informative, and flawless</p>
          
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

     <!--How to Get Started with Economic Assignment Help -->
     <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">How to Get Started with Economic Assignment Help</h2>

							 <p> Submitting your assignment is quick and easy with our user-friendly website. If you need help with a math problem, simply upload your assignment on our site. Once submitted, we will review it and provide you with a price quote that fits your budget, based on your specific needs and the assignment's complexity.                 
                             </p>

                             <p> Next, we will match your assignment with one of our highly qualified math experts who specializes in your field to ensure you receive the best assistance possible. The expert will then create a customized, step-by-step solution or detailed explanation tailored to your assignment needs. 
                             </p>

                             <p> If you require further assistance, we offer one-on-one tutoring sessions and additional resources to help you understand the concepts better and improve your math skills.
                             </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
        
     <!--Conclusion -->
     <!-- <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Conclusion</h2>

							 <p>Choosing our Economics assignment Help online means more than just finishing your assignments. It helps you truly understand how economics works. We’re here to help if you ever find yourself thinking, "I need someone to write my economics assignment,"                </p>
                             </p>

                             <p>We aim to help you not only achieve short-term academic success but also develop a deep appreciation for economics. Whether you're dealing with basic concepts or advanced topics our services are personalized to meet your specific learning needs. 
                             </p>

                              
						</div>
					</div>
				</div>
			</div>
		</div>
	</section> -->
     <!-- new code of conclusion -->
  
	<section class="case-study-section mt-5 conclsn">
    	<div class="auto-container">
		<div class="row clearfix">

			<!-- Content Column -->
			<div class="content-column col-lg-5 col-md-12 col-sm-12 ">
				<div class="inner-column">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="py-4">Conclusion </h2>
					<div class="text">
						<p> Choosing our Economics assignment Help online means more than just finishing your assignments. It helps you truly understand how economics works. We're here to help if you ever find yourself thinking, "I need someone to write my economics assignment,"
						</p>
						<p> We aim to help you not only achieve short-term academic success but also develop a deep appreciation for economics. Whether you're dealing with basic concepts or advanced topics our services are personalized to meet your specific learning needs.
						</p>
					</div>
					<!-- <a href="courses-single.html" class="theme-btn btn-style-seven"><span class="txt">Read Case
							Study</span></a> -->
				</div>
			</div>

			<!-- Image Column -->
			<div class="image-column col-lg-7 col-md-12 col-sm-12">
				<div class="inner-column">
					<div class="icon-layer-three" style="background-image:url(images2/icons/icon-12.png)"></div>
					<div class="icon-layer-four" style="background-image:url(images2/icons/icon-3.png)"></div>
					<div class="icon-layer-six" style="background-image:url(images2/icons/icon-2.png)"></div>
					<div class="image titlt" data-tilt="" data-tilt-max="4"
						style="will-change: transform; transform: perspective(300px) rotateX(0deg) rotateY(0deg);">
						<img src="images2/resource/case.png" alt="">
					</div>
				</div>
			</div>

		</div>
	</div>
</section>
	     <!-- end new code of conclusion -->
       	 <!-- FAQs Question  section for eco -->
	     <section class="faq-section ">
			        <div class="auto-container">
			    	<div class="row clearfix">
					<div class="column col-lg-12 col-md-12 col-sm-12">
					<div class="title-box">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Frequently asked questions</h2>
					</div>
                        <ul class="accordion-box">
							<li class="accordion block ">
								<div class="acc-btn">1. What is Economic Assignment Help?<div class="icon fa fa-angle-down"></div></div>
								<div class="acc-content">
									<div class="content">
										<div class="text">
											<p>Economic assignment help is support for students in topics like international economics, microeconomics, macroeconomics, and others. It helps students understand these subjects better and complete their assignments on time.</p>
										</div>
									</div>
								</div>
							</li>
							<li class="accordion block active-block">
								<div class="acc-btn active">2. Why should I choose your Economic Assignment Help services?                               
                                    <div class="icon fa fa-angle-down"></div></div>
								<div class="acc-content current">
									<div class="content">
										<div class="text">
											<p>We provide original content by tailoring each assignment and thoroughly checking for plagiarism. You can select your expert based on their qualifications and area of expertise. You'll work directly with your expert to customize your assignment precisely. Our thorough editing process ensures your work is clear, logical, and well-structured. Plus, we offer unlimited revisions to make sure the final product meets your academic requirements perfectly.</p>
										</div>
									</div>
								</div>
							</li>
							<li class="accordion block">
								<div class="acc-btn">3. How do I request Economic Assignment Help?<div class="icon fa fa-angle-down"></div></div>
								<div class="acc-content">
									<div class="content">
										<div class="text">
											<p>You can request economics assignment help online through our email INFO@ASSIGNNMENTINNEED.COM or by clicking the submit button on our website. 
                                            </p>
										</div>
									</div>
								</div>
							</li>
							<li class="accordion block">
								<div class="acc-btn">4. What types of economic assignments can you help with?<div class="icon fa fa-angle-down"></div></div>
								<div class="acc-content">
									<div class="content">
										<div class="text">
											<p>Assignment In Need helps with different areas of economics. We cover International Economics (trade between nations and global policies), Microeconomics (individual consumer and firm behavior), Macroeconomics (big economic factors like inflation and unemployment), Developmental Economics (growth in low-income countries), Environmental Economics (impact of environmental policies), Health Economics (healthcare systems and funding), and Labor Economics (employment trends and wages).</p>
										</div>
									</div>
								</div>
							</li>
                            <li class="accordion block">
								<div class="acc-btn">
                                    5. How long does it take to get my economic assignment completed?
                                    <div class="icon fa fa-angle-down">

                                    </div>
                                </div>
								<div class="acc-content">
									<div class="content">
										<div class="text">
											<p>Our main goal is to complete your assignment as quickly as possible. We typically deliver it a day before your deadline. In cases where deadlines are tight, such as a 3-day delivery, you can expect to receive your work on either the second or third day. </p>
										</div>
									</div>
								</div>
							</li>

                            <li class="accordion block">
								<div class="acc-btn">6. How can I contact you for further questions about Economic Assignment Help?<div class="icon fa fa-angle-down"></div></div>
								<div class="acc-content">
									<div class="content">
										<div class="text">
											<p>You can contact us in three different ways, first by email INFO@ASSIGNNMENTINNEED.COM . Call us on +44 2037695831, or just WhatsApp Number +44 7435256433.</p>
										</div>
									</div>
								</div>
							</li>

                           
						</ul>
					</div>
					
					
				 
			</div>
 </section>
          
@endsection